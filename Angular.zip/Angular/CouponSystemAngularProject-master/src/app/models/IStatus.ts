export interface  IStatus {
    message:string;
    success:boolean
    }