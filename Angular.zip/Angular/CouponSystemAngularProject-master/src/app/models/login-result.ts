export class LoginResult {
    public constructor(public isLoggedIn: boolean, public type: string) {}
}