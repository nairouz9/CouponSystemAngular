import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-actions',
  templateUrl: './comp-actions.component.html',
  styleUrls: ['./comp-actions.component.css']
})
export class CompActionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
