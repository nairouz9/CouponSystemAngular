export interface  ICompany {
    companyId:number;
    companyName:string;
    companyPassword:string;
    companyEmail:string;
    }