import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-operations',
  templateUrl: './cust-operations.component.html',
  styleUrls: ['./cust-operations.component.css']
})
export class CustOperationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
