import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-operations',
  templateUrl: './comp-operations.component.html',
  styleUrls: ['./comp-operations.component.css']
})
export class CompOperationsComponent {

  constructor() { }
 
      

  
}
