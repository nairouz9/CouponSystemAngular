import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-actions',
  templateUrl: './cust-actions.component.html',
  styleUrls: ['./cust-actions.component.css']
})
export class CustActionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
