export interface  ICustomer {
    customerId:number;
    customerName:string;
    customerPassword:string;
    }